<?php
$host = "localhost";
$user = "digital24_telegrambot";
$pass = "digital24_telegrambot";
$db   = "digital24_telegrambot";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("❌ DB connection failed: " . $conn->connect_error);
} else {
    echo "✅ Database connected successfully!";
}
?>