<?php
// ডাটাবেজ কানেকশন
include 'db.php';

// বট টোকেন
$token = "7937408258:AAG0SwVVa3JYEGKGOabuL8xE0v2uDtv-DT4";

// টেলিগ্রাম থেকে ইনপুট পড়া ও লগ ফাইলে লেখা
$update = json_decode(file_get_contents("php://input"), true);
file_put_contents("log.txt", date("Y-m-d H:i:s") . " - " . json_encode($update) . "\n", FILE_APPEND);

// যদি মেসেজ আসে
if (isset($update['message'])) {
    $message = $update['message']['text'] ?? '';
    $chat_id = $update['message']['chat']['id'];
    $first_name = $update['message']['from']['first_name'] ?? '';
    $username = $update['message']['from']['username'] ?? '';
    $ref_code = null;

    // রেফারেল কোড চেক
    if (preg_match('/^\/start ref_(\d+)$/', $message, $match)) {
        $ref_code = $match[1];
    }

    // প্রোফাইল ফটো আনার চেষ্টা
    $photo_url = "";
    $photo_info = file_get_contents("https://api.telegram.org/bot$token/getUserProfilePhotos?user_id=$chat_id&limit=1");
    $photo_data = json_decode($photo_info, true);
    $file_id = $photo_data['result']['photos'][0][0]['file_id'] ?? null;
    if ($file_id) {
        $file_info = json_decode(file_get_contents("https://api.telegram.org/bot$token/getFile?file_id=$file_id"), true);
        $file_path = $file_info['result']['file_path'] ?? '';
        if ($file_path) {
            $photo_url = "https://api.telegram.org/file/bot$token/$file_path";
        }
    }

    // ইউজার আছে কিনা চেক
    $stmt_check = $conn->prepare("SELECT id FROM users WHERE telegram_id = ?");
    $stmt_check->bind_param("i", $chat_id);
    $stmt_check->execute();
    $result = $stmt_check->get_result();

    if ($result->num_rows == 0) {
        // নতুন ইউজার ইনসার্ট
        $ref = is_numeric($ref_code) ? (int)$ref_code : 0; // null এর জায়গায় 0 দিবেন
        $stmt = $conn->prepare("INSERT INTO users (telegram_id, first_name, username, referred_by, photo) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("issis", $chat_id, $first_name, $username, $ref, $photo_url);
        if (!$stmt->execute()) {
            file_put_contents("sql_error.txt", "INSERT ERROR: " . $stmt->error . "\n", FILE_APPEND);
        }
    } else {
        // আগের ইউজার, আপডেট করুন
        $stmt = $conn->prepare("UPDATE users SET first_name = ?, username = ?, photo = ? WHERE telegram_id = ?");
        $stmt->bind_param("sssi", $first_name, $username, $photo_url, $chat_id);
        if (!$stmt->execute()) {
            file_put_contents("sql_error.txt", "UPDATE ERROR: " . $stmt->error . "\n", FILE_APPEND);
        }
    }

    // ইউজার ডেটা ফেচ
    $stmt_user = $conn->prepare("SELECT balance, earnings, tasks, referral FROM users WHERE telegram_id = ?");
    $stmt_user->bind_param("i", $chat_id);
    $stmt_user->execute();
    $user_data = $stmt_user->get_result()->fetch_assoc();

    $balance = $user_data['balance'] ?? 0;
    $earnings = $user_data['earnings'] ?? 0;
    $tasks = $user_data['tasks'] ?? 0;
    $referral = $user_data['referral'] ?? 0;

    // Welcome টেক্সট
    $text = "**👋 হ্যালো, $first_name!**\n";
    $text .= "🎉 আপনি সফলভাবে যুক্ত হয়েছেন আমাদের Task Bot এ!\n\n";
    $text .= "📊 আপনার বর্তমান তথ্য:\n";
    $text .= "💰 *Balance:* `$balance`\n";
    $text .= "📈 *Total Earnings:* `$earnings`\n";
    $text .= "✅ *Tasks Completed:* `$tasks`\n";
    $text .= "🤝 *Referral Income:* `$referral`\n";

    // Inline বাটন
    $buttons = [
        'inline_keyboard' => [
            [['text' => '🎁 Daily Check-in', 'callback_data' => 'checkin']],
            [['text' => '👥 Refer & Earn', 'url' => "https://t.me/testskgbot_bot?start=ref_$chat_id"]],
            [['text' => '🌐 Open App', 'url' => "https://bot.digital24.agency/index.php?telegram_id=$chat_id"]]
        ]
    ];

    // মেসেজ পাঠানো
    file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query([
        'chat_id' => $chat_id,
        'text' => $text,
        'parse_mode' => 'Markdown',
        'reply_markup' => json_encode($buttons)
    ]));
}

// Telegram API কে ok রেসপন্স দিন
echo json_encode(["ok" => true]);
?>